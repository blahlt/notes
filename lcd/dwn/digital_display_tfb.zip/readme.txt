DIGITAL DISPLAY TFB (TRUE FONTS BLOG).

Link to the ttf http://truefonts.blogspot.com/2012/11/digital-display-tfb.html

Link to my blog http://truefonts.blogspot.com


Is a donationware font =) [with a smile or a comment often enough to make happy amateur designer]


Thanks for download

